package correcaminos;

public class Vuelta {
	private int numero;
	private double segundos;
	
	public Vuelta(int numero, double segundos) {
		this.setNumero(numero);
		this.setSegundos(segundos);
	}
	
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public double getSegundos() {
		return segundos;
	}
	public void setSegundos(double segundos) {
		this.segundos = segundos;
	}

	@Override
	public String toString() {
		return "Vuelta [numero=" + numero + ", segundos=" + segundos + "]";
	}
	
	
}
