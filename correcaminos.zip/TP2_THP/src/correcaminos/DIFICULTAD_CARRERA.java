package correcaminos;

public enum DIFICULTAD_CARRERA {
	PRINCIPIANTE, AVANZADO, AS_DEL_VOLANTE
}
