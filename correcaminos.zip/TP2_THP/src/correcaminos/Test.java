package correcaminos;

public class Test {

	public static void main(String[] args) {
		
		Empresa CorreCaminos = new Empresa("CorreCaminos");
		
		Carrera carrera = new Carrera("1/11", 16.00, DIFICULTAD_CARRERA.AS_DEL_VOLANTE);
		
		Piloto juan = new Piloto("4287", "juan");
		Piloto nacho = new Piloto("4287", "nacho");
		
		Vuelta v1 = new Vuelta(1, 19.00);
		Vuelta v2 = new Vuelta(2, 16.00);
		
		Vuelta v3 = new Vuelta(1, 14.00);
		Vuelta v4 = new Vuelta(2, 10.00);
		
		juan.agregarVuelta(v1);
		juan.agregarVuelta(v2);
		nacho.agregarVuelta(v3);
		nacho.agregarVuelta(v4);
		
		carrera.agregarPiloto(juan);
		carrera.agregarPiloto(nacho);

		System.out.println(carrera.buscarPilotosPorDebajoDe(15));
		
		carrera.mostrarMenorPromedio();
		
		CorreCaminos.agregarCarrera(carrera);
		
		System.out.println(CorreCaminos.pilotosPorCarrera());
		
	}

}
