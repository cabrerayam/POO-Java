package correcaminos;

import java.util.ArrayList;

public class PilotosPorFecha {
	private String fecha;
	private int cantidadPilotos;
	
	public PilotosPorFecha(String fecha, int cantidadPilotos) {
		this.fecha = fecha;
		this.cantidadPilotos = cantidadPilotos;
	}
	
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public int getCantidadPilotos() {
		return cantidadPilotos;
	}
	public void setCantidadPilotos(int cantidadPilotos) {
		this.cantidadPilotos = cantidadPilotos;
	}

	@Override
	public String toString() {
		return "PilotosPorFecha [fecha=" + fecha + ", cantidadPilotos=" + cantidadPilotos + "]";
	}
	
	
}
