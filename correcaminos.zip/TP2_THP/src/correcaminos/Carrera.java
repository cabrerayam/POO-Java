package correcaminos;

import java.util.ArrayList;

public class Carrera {
	private String fecha;
	private double hora;
	private DIFICULTAD_CARRERA dificultad;
	private ArrayList<Piloto> listaPilotos;
	
	public Carrera(String fecha, double hora, DIFICULTAD_CARRERA dificultad) {
		this.setFecha(fecha);
		this.setHora(hora);
		this.setDificultad(dificultad);
		this.listaPilotos = new ArrayList<>();
	}
	
	
	public int getCantidadDePilotos() {
		return this.listaPilotos.size();
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public double getHora() {
		return hora;
	}
	public void setHora(double hora) {
		this.hora = hora;
	}
	public DIFICULTAD_CARRERA getDificultad() {
		return dificultad;
	}
	public void setDificultad(DIFICULTAD_CARRERA dificultad) {
		this.dificultad = dificultad;
	}
	
	public ArrayList<Piloto> buscarPilotosPorDebajoDe(double segundos){
		ArrayList<Piloto> pilotosPorDebajo = new ArrayList<>();
		
		for(Piloto piloto: listaPilotos) {
			double promedio = piloto.calcularPromedio();
			if(piloto.getCantidadVueltas() >= 2 && promedio < segundos) {
				pilotosPorDebajo.add(piloto);
			}
		}
		
		return pilotosPorDebajo;
	}
	
	public void mostrarMenorPromedio() {
		Piloto pilotoMenorPromedio = null;
		double promedio = 0;
		double menorPromedio = Double.MAX_VALUE;
		
		for(Piloto piloto: listaPilotos) {
			promedio = piloto.calcularPromedio();
			if(promedio < menorPromedio) {
				menorPromedio = promedio;
				pilotoMenorPromedio = piloto;
			}
		}
		
		System.out.println("El piloto con menor promedio es:");
		System.out.println("Nombre: " + pilotoMenorPromedio.getNombre());
		System.out.println("Dni: " + pilotoMenorPromedio.getDni());
		System.out.println("Promedio: " + menorPromedio);
	}
	
	public void agregarPiloto(Piloto piloto) {
		this.listaPilotos.add(piloto);
	}


	@Override
	public String toString() {
		return "Carrera [fecha=" + fecha + ", hora=" + hora + ", dificultad=" + dificultad + ", listaPilotos="
				+ listaPilotos + "]";
	}
	
	
}
