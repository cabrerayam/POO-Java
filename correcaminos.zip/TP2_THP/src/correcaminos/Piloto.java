package correcaminos;

import java.util.ArrayList;

public class Piloto {
	private String dni;
	private String nombre;
	private ArrayList<Vuelta> listaVueltas;
	private boolean seCompleto;
	
	public Piloto(String dni, String nombre) {
		this.setDni(dni);
		this.setNombre(nombre);
		this.setSeCompleto(false);
		this.listaVueltas = new ArrayList<>();
	}
	
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public boolean isSeCompleto() {
		return seCompleto;
	}
	public void setSeCompleto(boolean seCompleto) {
		this.seCompleto = seCompleto;
	}
	
	public int getCantidadVueltas(){
		int cantVueltas = this.listaVueltas.size();
		return cantVueltas;
	}
	
	public double calcularPromedio() {
		double promedio = 0;
		double sumaTotal = 0;
		
		for(Vuelta v: listaVueltas) {
			sumaTotal = sumaTotal + v.getSegundos();
		}
		
		promedio = Matematica.obtenerPromedio(sumaTotal, listaVueltas.size());
		
		return promedio;
	}
	
	public void agregarVuelta(Vuelta vuelta) {
		this.listaVueltas.add(vuelta);
	}

	@Override
	public String toString() {
		return "Piloto [dni=" + dni + ", nombre=" + nombre + ", listaVueltas=" + listaVueltas + ", seCompleto="
				+ seCompleto + "]";
	}
	
	
}
