package correcaminos;

import java.util.ArrayList;

public class Empresa {
	private String nombre;
	private ArrayList<Carrera> listaCarreras;
	
	public Empresa(String nombre) {
		this.setNombre(nombre);
		this.listaCarreras =  new ArrayList<>();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	private Carrera buscarCarrera(String fecha) {
		Carrera carrera = null;
		int i = 0;
		
		while(carrera == null && i < this.listaCarreras.size()) {
			if(this.listaCarreras.get(i).getFecha().equals(fecha)) {
				carrera = this.listaCarreras.get(i);
			}
			i++;
		}
		
		return carrera;
	}
	
	public ArrayList<PilotosPorFecha> pilotosPorCarrera(){
		ArrayList<PilotosPorFecha> pilotosPorFecha = new ArrayList<>();
		
		for(Carrera carrera: listaCarreras) {
			String fecha = carrera.getFecha();
			int cantidadPilotos = carrera.getCantidadDePilotos();
			PilotosPorFecha pilotosPorCarrera = new PilotosPorFecha(fecha, cantidadPilotos);
			pilotosPorFecha.add(pilotosPorCarrera);
		}
		
		return pilotosPorFecha;
	}
	
	public void agregarCarrera(Carrera carrera) {
		this.listaCarreras.add(carrera);
	}

	@Override
	public String toString() {
		return "Empresa [nombre=" + nombre + ", listaCarreras=" + listaCarreras + "]";
	}
	
	
}
