package correcaminos;

public class Matematica {
	public static double obtenerPromedio(double sumaTotal, int cantidad) {
		double miPromedio = 0;
		
		miPromedio = (double)sumaTotal/cantidad;
		
		return miPromedio;
	}
}
